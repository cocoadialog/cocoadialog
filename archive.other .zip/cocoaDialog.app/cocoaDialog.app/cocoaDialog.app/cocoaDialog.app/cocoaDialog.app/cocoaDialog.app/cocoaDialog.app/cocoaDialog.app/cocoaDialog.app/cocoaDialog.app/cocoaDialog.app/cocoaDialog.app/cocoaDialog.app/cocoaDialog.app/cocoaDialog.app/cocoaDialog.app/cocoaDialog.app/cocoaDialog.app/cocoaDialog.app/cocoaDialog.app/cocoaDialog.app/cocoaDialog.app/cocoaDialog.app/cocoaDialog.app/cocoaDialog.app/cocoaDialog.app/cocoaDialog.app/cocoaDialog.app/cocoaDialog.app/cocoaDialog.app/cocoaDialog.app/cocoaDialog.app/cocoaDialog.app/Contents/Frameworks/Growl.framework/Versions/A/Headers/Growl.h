#include <Growl/GrowlDefines.h>

#ifdef __OBJC__
#	include <Growl/GrowlApplicationBridge.h>
#endif
