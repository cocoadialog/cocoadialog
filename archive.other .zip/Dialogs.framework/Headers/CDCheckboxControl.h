//
//  CDCheckboxControl.h
//  cocoaDialog
//
//  Created by Mark Whitaker on 9/20/11.
//  Copyright (c) 2011 Mark Whitaker. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CDThreeButtonControl.h"

@interface CDCheckboxControl : CDThreeButtonControl
{
    NSMutableArray *checkboxes;
}
@end
