/*
	CDControl.h
	cocoaDialog
	Copyright (C) 2004-2011 Mark A. Stratman <mark@sporkstorms.org>
 
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
 
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
 
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#import <Foundation/Foundation.h>
@import ToolKit;

#import "CDCommon.h"

#import "CDIcon.h"
#import "CDPanel.h"

// All controls must include the methods createControl and validateOptions.
// This should look at the options and display a control (dialog with message,
// inputbox, or whatever) to the user, get any necessary info from it, and
// return an NSArray of NSString objects.
// Each NSString is printed to stdout on its own line.
// Return an empty NSArray if there is no output to be printed, or nil
// on error.
@protocol CDControl

@optional


- (void) createControl;

@property (readonly) BOOL validateOptions;
#pragma mark - Subclassable Control Methods
@required
// This must be overridden if you want local global options for your control
@property (readonly, copy) NSDictionary *globalAvailableKeys;

@end

/*! CDControl provides a runControl method.
    It invokes runControlFromOptions: with the options specified in initWithOptions:
    @warning You must override runControlFromOptions.
 */
@interface CDControl : CDCommon  <CDControl>
{
    CDIcon                      *icon;                                  // Classes
    CDPanel                     *panel;

   IBOutlet NSPanel            *controlPanel;                         // Outlets
    IBOutlet NSImageView        *controlIcon;
    IBOutlet NSTextField        *timeoutLabel;

    int                         controlExitStatus;                     // Variables
    NSString                    *controlExitStatusString;
    NSMutableArray              *controlItems, *controlReturnValues;

    NSThread                    *mainThread, *timerThread;               // Timer
    NSTimer                     *timer;
    float                       timeout;
}


@property (readonly, copy) NSString *controlNib;

- (NSString *) formatSecondsForString:(NSInteger)timeInSeconds;
- (void) stopControl;
- (BOOL) loadControlNib:(NSString *)nib;
+ (void) printHelpTo:(NSFileHandle *)fh;
- (void) runControl;
- (void) setTimeout;
- (void) setTimeoutLabel;
//- (CDOptions *) controlOptionsFromArgs:(NSArray *)args withGlobalKeys:(NSDictionary *)globalKeys;

// This must be sub-classed if you want options local to your control
@property (readonly, copy) NSDictionary *availableKeys;

// This must be sub-classed if you want specify local depreciated keys for your control
@property (readonly, copy) NSDictionary *depreciatedKeys;

// This must be sub-classed if you want validate local options for your control
//- (BOOL) validateControl:(CDOptions *)options;



@end




@interface ModuleController : NSObject

+ (NSDictionary *) availableControls;
@end
