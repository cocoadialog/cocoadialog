//
//  CDGrowl.h
//  cocoaDialog
//
//  Created by Mark Whitaker on 10/1/11.
//  Copyright (c) 2011 Mark Whitaker. All rights reserved.
//

#import <Growl/Growl.h>
#import "CDNotifyControl.h"

@interface CDGrowlControl : CDNotifyControl <GrowlApplicationBridgeDelegate>

@end
