//
//  CDCommon.h
//  cocoaDialog
//
//  Created by Mark Whitaker on 10/29/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

@import ToolKit;

#define CDOptionsNoValues       0
#define CDOptionsOneValue       1
#define CDOptionsMultipleValues 2

// Simple wrapper for commandline options.

// Easily used with [CDOptions getOpts:[[NSProcessInfo processInfo] arguments]]

//@interface CDOptions : NSObject
//
//// availableKeys should be an NSString key, and an NSNumber int value using one of the constants defined above.
//
//@property (readonly, copy) NSArray *allOptions;
//- (void) setOption:value forKey:(NSString *)key;
//
//- (BOOL) hasOpt:(NSString *)key;
//
//- (NSString*) optValue:(NSString*)k;
//- (NSArray*) optValues:(NSString*)k;
//-     optValueOrValues:(NSString*)k;
//
//+ (instancetype) getOpts:(NSArray *)args availableKeys:(NSDictionary *)availableKeys depreciatedKeys:(NSDictionary *)depreciatedKeys;
//
//+ (void)printOpts:(NSArray *)availableOptions forRunMode:(NSString *)runMode;
//
//@property (readonly, copy) NSArray *allOptValues;
//
//@end

@protocol CDCommon <NSObject>
@optional
_VD setUp;

@concrete
@property (readonly) _Dict options;
- initWithOptions __Dict_ o;
_VD debug:(NSString *)message;
@end

@interface CDCommon : NSObject <CDCommon>
//@property CDOptions *options;
//- initWithOption:(CDOptions*)newOptions;
@end


@interface Dict (hasopt)
_IT hasOpt __Text_ k ___
- optValue __Text_ k ___
_LT optValues __Text_ k ___

@end
